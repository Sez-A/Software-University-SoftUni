package barracksWars.interfaces;

public interface Executable {

	String execute();

}
