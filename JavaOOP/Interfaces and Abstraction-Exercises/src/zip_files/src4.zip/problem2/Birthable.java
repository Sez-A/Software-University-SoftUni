package problem2;

public interface Birthable {
    String getBirthDate();
}
