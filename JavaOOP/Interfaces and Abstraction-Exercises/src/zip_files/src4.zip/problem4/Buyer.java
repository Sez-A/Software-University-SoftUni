package problem4;

public interface Buyer {

    void buyFood();
    int getFood();
}
