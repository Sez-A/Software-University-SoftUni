package problem5;

public interface Callable {
    String call();
}
