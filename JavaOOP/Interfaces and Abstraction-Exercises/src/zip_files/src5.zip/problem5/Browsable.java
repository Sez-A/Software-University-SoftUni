package problem5;

public interface Browsable {
    String browse();
}
