package problem1;

public interface Person {

    String getName();

    int getAge();
}
