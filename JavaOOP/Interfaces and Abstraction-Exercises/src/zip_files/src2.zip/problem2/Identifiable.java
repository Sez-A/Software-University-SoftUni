package problem2;

public interface Identifiable {
    String getId();
}
