package aquarium.entities.decorations;

public class Plant extends BaseDecoration{
    public Plant() {
        super(5, 10);
    }
}
