package onlineShop;

import onlineShop.core.EngineImpl;
import onlineShop.core.interfaces.Engine;
import onlineShop.models.products.components.CentralProcessingUnit;
import onlineShop.models.products.components.Component;
import onlineShop.models.products.peripherals.Mouse;
import onlineShop.models.products.peripherals.Peripheral;

public class Main {
    public static void main(String[] args) {
        Component component =  new CentralProcessingUnit(1,"a","a",1,50, 1);
        System.out.println(component);
        Peripheral peripheral = new Mouse(1,"Seza","Rock",12,40,"Type");
        System.out.println(peripheral);
        Engine engine = new EngineImpl();
        engine.run();
    }
}
