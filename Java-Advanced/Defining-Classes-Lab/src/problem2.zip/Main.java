import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int n = Integer.parseInt(scan.nextLine());

        List<Car> carList = new ArrayList<>();

        while (n-- > 0) {
            String[] tokens = scan.nextLine().split("\\s+");
            String brand = tokens[0];

            if(tokens.length == 1) {
                Car car = new Car(brand);
                carList.add(car);
            }else {
                String model = tokens[1];
                int horsePower = Integer.parseInt(tokens[2]);
                Car car = new Car(brand,model,horsePower);
                carList.add(car);
            }
        }

        for (Car car : carList) {
            System.out.println(car.carInfo());
        }

    }
}
