import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String input = "";
        int bankAccIds = 1;
        List<BankAccount> bankAccounts = new ArrayList<>();
        while (!(input = scan.nextLine()).equals("End")) {
            String[] tokens = input.split("\\s+");
            switch (tokens[0]) {
                case "Create":
                    BankAccount bankAccount = new BankAccount();
                    bankAccounts.add(bankAccount);
                    System.out.printf("Account ID%d created%n", bankAccIds++);
                    break;
                case "Deposit":
                    //•	Deposit {Id} {Amount}
                    if (bankAccounts.size() >= Integer.parseInt(tokens[1])) {
                        bankAccounts.get(Integer.parseInt(tokens[1]) - 1).
                                deposit(Double.parseDouble(tokens[2]));
                        System.out.printf("Deposited %s to ID%s%n", tokens[2], tokens[1]);
                    } else {
                        System.out.println("Account does not exist");
                    }
                    break;
                case "SetInterest":
                    BankAccount.setInterestRate(Double.parseDouble(tokens[1]));
                    break;
                case "GetInterest":
                    //•	GetInterest {ID} {Years}
                    int id = Integer.parseInt(tokens[1]);
                    int years = Integer.parseInt(tokens[2]);
                    if(id <= bankAccounts.size()) {
                        BankAccount current = bankAccounts.get(id - 1);
                        System.out.println(String.format("%.2f", current.getInterest(years)));
                    }else {
                        System.out.println("Account does not exist");
                    }
                    break;
            }
        }
    }
}
