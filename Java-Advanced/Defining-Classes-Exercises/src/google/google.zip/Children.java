package google;

public class Children extends Parent{

    public Children(String name, String birthday) {
        super(name, birthday);
    }
}
