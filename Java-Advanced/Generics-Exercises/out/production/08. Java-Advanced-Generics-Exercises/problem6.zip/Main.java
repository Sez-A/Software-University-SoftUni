import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int n = Integer.parseInt(scan.nextLine());
        Box<Double> box = new Box<>();

        while (n-- > 0) {
            box.add(Double.parseDouble(scan.nextLine()));
        }

        double target = Double.parseDouble(scan.nextLine());

        System.out.println(box.greaterElementsCnt(target));
    }
}
