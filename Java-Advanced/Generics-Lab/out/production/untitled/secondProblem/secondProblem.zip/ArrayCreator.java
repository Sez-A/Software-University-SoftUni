package secondProblem;

import java.lang.reflect.Array;

public class ArrayCreator{
    @SuppressWarnings("unchecked")
     static <T> T[] create(int length, T item) {
        T[] ts = (T[]) Array.newInstance(item.getClass(), length);
        for (int i = 0; i < length; i++) {
            ts[i] = item;
        }
        return ts;
    }
    @SuppressWarnings("unchecked")
     static <T> T[] create(Class<T> clazz, int length, T item) {
        return (T[]) Array.newInstance(clazz, length);
    }
}
