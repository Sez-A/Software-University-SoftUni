import java.util.ArrayList;
import java.util.List;

public class ListyIterator {
    private List<String> collection;
    private int index;
    private int hasNextIndex;

    public ListyIterator(String... varargs) {
        this.collection = new ArrayList<>();
        this.index = 0;
        this.hasNextIndex = 0;

        for (String element : varargs) {
            this.collection.add(element);
        }
    }

    public boolean move() {
        if (this.hasNext()) {
            index++;
            return true;
        }
        return false;
    }

    public void print() {
        System.out.println(this.collection.get(index));
    }

    public boolean hasNext() {
        if (this.index < this.collection.size() - 1) {
            return true;
        }
        return false;

    }

    public boolean isEmpty() {
        return this.collection.isEmpty();
    }
}
