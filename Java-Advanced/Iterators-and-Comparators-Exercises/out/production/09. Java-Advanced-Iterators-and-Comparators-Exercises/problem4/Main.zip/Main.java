import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int[] array = Arrays.stream(scan.nextLine().split(", "))
                .mapToInt(Integer::parseInt)
                .toArray();


        List<Integer> evenIndexes = new ArrayList<>();
        List<Integer> oddIndexes = new ArrayList<>();

        for (int i = 0; i < array.length; i++) {
            Integer currentNum = array[i];
            if (i % 2 == 0) {
                evenIndexes.add(currentNum);
            } else {
                oddIndexes.add(currentNum);
            }
        }

        List<String> oddIndexesStringList = convertToStringList(oddIndexes);
        List<String> evenIndexesStringList = convertToStringList(evenIndexes);

        printFinalResult(oddIndexesStringList, evenIndexesStringList);

    }

    private static void printFinalResult(List<String> evenIndexes, List<String> oddIndexes) {
        StringBuilder sb = new StringBuilder();
        boolean oddIndexesNotEmpty = false;
        if (!oddIndexes.isEmpty()) {
            sb.append(String.join(", ", oddIndexes));
            oddIndexesNotEmpty = true;
        }

        if (!evenIndexes.isEmpty()) {
            if (oddIndexesNotEmpty) {
                sb.append(", ");
            }
            sb.append(String.join(", ", evenIndexes));
        }
        System.out.println(sb);
    }

    private static <T> List<String> convertToStringList(List<T> list) {
        List<String> stringList = new ArrayList<>();
        for (T element : list) {
            stringList.add(String.valueOf(element));
        }
        return stringList;
    }
}
