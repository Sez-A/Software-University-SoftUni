import java.util.Arrays;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
//        Integer[] numbers = Arrays.stream(scan.nextLine().split(", "))
//                .skip(1)
//                .mapToInt(Integer::parseInt)
//                .boxed()
//                .toArray(Integer[]::new);

        CustomStack stack = new CustomStack();
        String command = scan.nextLine();
        while (!command.equals("END")) {
            if (command.startsWith("Pus")) {
                String sub = command.substring(command.lastIndexOf("h") + 2);
                sub = sub.trim();
                Integer[] numbers = Arrays.stream(sub.split(", "))
                        //  .skip(1)
                        .mapToInt(Integer::parseInt)
                        .boxed()
                        .toArray(Integer[]::new);
                stack.push(numbers);
            } else if (command.equals("Pop")) {
                try {
                    stack.pop();
                } catch (NoSuchElementException e) {
                    System.out.println("No elements");
                }
            }
            command = scan.nextLine();
        }

        for (int i = 0; i < 2; i++) {
            for (Integer num : stack) {
                System.out.println(num);
            }
        }
    }
}
