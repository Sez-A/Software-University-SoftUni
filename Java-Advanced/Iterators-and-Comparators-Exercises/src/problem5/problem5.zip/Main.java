import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String input = "";

        List<Person> people = new ArrayList<>();
        while (!(input = scan.nextLine()).equals("END")) {
            String[] tokens = input.split("\\s+");
            people.add(new Person(tokens[0], Integer.parseInt(tokens[1]), tokens[2]));
        }

        int NthPerson = Integer.parseInt(scan.nextLine());

        if (NthPerson < 0 || NthPerson >= people.size()) {
            System.out.println("No matches");
        } else {

            Person target = people.get(NthPerson);
            int matchCnt = 0;
            int notMatchCnt = 0;

            for (Person person : people) {
                if (person.compareTo(target) == 0) {
                    matchCnt++;
                } else {
                    notMatchCnt++;
                }
            }
            System.out.printf("%d %d %d%n", matchCnt, notMatchCnt, people.size());
        }
    }
}
