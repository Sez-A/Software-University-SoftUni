import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String[] tokens = Arrays.stream(scan.nextLine().split("\\s+"))
                .skip(1)
                .toArray(String[]::new);

        ListyIterator listyIterator = new ListyIterator();
        if (tokens.length > 1) {
            listyIterator = new ListyIterator(tokens);
        }

        String command = scan.nextLine();
        while (!command.equals("END")) {
            switch (command) {
                case "Move":

                    System.out.println(listyIterator.move());

                    break;
                case "HasNext":

                    System.out.println(listyIterator.hasNext());

                    break;
                case "Print":
                    if (listyIterator.isEmpty()) {
                        System.out.println("Invalid Operation!");
                    } else {
                        listyIterator.print();
                    }
                    break;
                case "PrintAll":
                    System.out.println(listyIterator.printAll());
                    break;
            }
            command = scan.nextLine();
        }
    }
}
